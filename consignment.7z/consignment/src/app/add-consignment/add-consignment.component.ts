import { DataParserService } from './../service/data-parser.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'add-consignment',
  templateUrl: './add-consignment.component.html',
  styleUrls: ['./add-consignment.component.css']
})
export class AddConsignmentComponent implements OnInit {

  constructor(private myService:DataParserService) { }

  ngOnInit() {
  }

  form = new FormGroup({
    firstName : new FormControl('', [
      Validators.required,
      Validators.minLength(3)
    ]),
    lastName : new FormControl('', [
      Validators.required,
      Validators.minLength(3)
    ]),
    emailID : new FormControl('', [
      Validators.required,
      Validators.minLength(5)
    ])

  })

  _addToTable() {
    console.log("Form",this.form);
    this.myService.postConsignmentList(this.form.value).subscribe(
      Response => {
        console.log(Response.json());
      }
    )

  }


}
