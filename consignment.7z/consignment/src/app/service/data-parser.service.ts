import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class DataParserService {
  url: string = "http://localhost:3000/consignmentDetails";
  originalRowToEdit: any;
  constructor(private http : Http) { }

  getConsignmentList() {
    return this.http.get(this.url); 
  }

  postConsignmentList(objToPost) {
    return this.http.post(this.url, objToPost); 
  }

  deleteConsignmentRow(id) {
    return this.http.delete(this.url + '/' + id);
  }

  setEditInitials(consignment) {
    this.originalRowToEdit = consignment;
  }

  getEditInitials() {
    return this.originalRowToEdit;
  }

  editConsignmentList(id, consignment) {
    return this.http.put(this.url + '/' + id, consignment);
  }
 }
