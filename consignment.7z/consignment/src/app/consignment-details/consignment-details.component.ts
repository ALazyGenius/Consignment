import { DataParserService } from './../service/data-parser.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Response } from '@angular/http/src/static_response';

@Component({
  selector: 'consignment-details',
  templateUrl: './consignment-details.component.html',
  styleUrls: ['./consignment-details.component.css']
})
export class ConsignmentDetailsComponent implements OnInit {
  data: any[];
  consignmentFlag: boolean = true;
  constructor(private dataParserService: DataParserService, private router: Router) {

  }

  ngOnInit() {
    console.log(this.dataParserService.getConsignmentList());
    this.dataParserService.getConsignmentList().subscribe(consignmentList => {
      this.data = consignmentList.json();
      console.log("LIST ***", this.data);
    });
  }

  _add() {
    this.router.navigate(['\add-consignment']);
    this.consignmentFlag = false;
  }

  _delete(id) {
    var deleteRow = confirm("Are you sure you want to delete?");
    if (deleteRow == true) {
      this.dataParserService.deleteConsignmentRow(id).subscribe(
        Response => {
          console.log(Response.json());
          for (var i = 0; i < this.data.length; i++) {
            if (this.data[i].id == id) {
              this.data.splice(i, 1);
            }
          }

        }
      )
    }
  }

  _edit(consignment) {
    this.consignmentFlag = false;
    this.dataParserService.setEditInitials(consignment);
    this.router.navigate(['/edit-consignment']);
  }

}