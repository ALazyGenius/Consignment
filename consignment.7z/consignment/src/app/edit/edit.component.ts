import { DataParserService } from './../service/data-parser.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Response } from 'selenium-webdriver/http';

@Component({
  selector: 'edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  rowValues: any;
  id: ;
  constructor(private myService: DataParserService) {
    this.rowValues = this.myService.getEditInitials();
    console.log("Row to edit", this.rowValues);
  }

  ngOnInit() {
  }

  form = new FormGroup({
    firstName: new FormControl('', [
      Validators.required,
      Validators.minLength(3)
    ]),
    lastName: new FormControl('', [
      Validators.required,
      Validators.minLength(3)
    ]),
    emailID: new FormControl('', [
      Validators.required,
      Validators.minLength(5)
    ])

  })

  _editTheRow() {
    var consignmentToUpdate;
    console.log("Edit Form Value", this.form.value);
    var editFormValue = this.form.value;
    for (var propName in editFormValue) {
      if (editFormValue[propName] === "") {
        delete editFormValue[propName];
      }
    }
    for (var propkeyName in this.rowValues) {
      for (var propkeyNameNewForm in editFormValue) {
        if (propkeyNameNewForm === propkeyName) {
          this.rowValues[propkeyName] = editFormValue[propkeyNameNewForm];
        }
      }
    }
    console.log("this.rowValues", this.rowValues);
    this.id = this.rowValues.id;
    this.myService.editConsignmentList(this.id, this.rowValues).subscribe(
      Response => {
        console.log(Response.json());
      }
    )
  }

}
